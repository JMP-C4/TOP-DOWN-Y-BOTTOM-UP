
import pytest
from biblioteca_sistema import BibliotecaSistema
from stubs.database_stub import DatabaseStub
from stubs.auth_stub import AuthStub

# ================== PRUEBA CASO EXITOSO ==================
def test_prestamo_exitoso():
  
    print("\n=== CONFIGURANDO ESCENARIO EXITOSO ===")
    
    
    db_stub = DatabaseStub()        # Simula base de datos
    auth_stub = AuthStub()          # Simula sistema de autenticación
    
    # Inyectar stubs en el sistema principal
    sistema = BibliotecaSistema(db_stub, auth_stub)
    
    print("✅ Stubs creados e inyectados")
    
    # ⚡ ACT (Actuar): Ejecutar la operación a probar
    print("\n=== EJECUTANDO OPERACIÓN ===")
    
    # Llamar al método principal con datos válidos
    resultado = sistema.prestar_libro(usuario_id=1, libro_id=2)
    
    print(f"📋 Resultado obtenido: {resultado}")
    
    # 🎯 ASSERT (Afirmar): Verificar que el resultado es correcto
    print("\n=== VERIFICANDO RESULTADO ===")
    assert resultado == "Préstamo exitoso", f"Esperado 'Préstamo exitoso', pero obtuve '{resultado}'"
    print("✅ ¡Prueba EXITOSA! El sistema funciona correctamente")

# ================== PRUEBA CASO DE ERROR ==================
def test_usuario_no_autorizado():

    # 🔧 ARRANGE: Preparar escenario de rechazo
    print("\n=== CONFIGURANDO ESCENARIO DE RECHAZO ===")
    
    db_stub = DatabaseStub()    # Base de datos simulada
    auth_stub = AuthStub()      # Autenticación simulada 
    sistema = BibliotecaSistema(db_stub, auth_stub)
    
    print("✅ Sistema configurado para prueba negativa")
    
    # ⚡ ACT: Intentar operación con usuario inválido
    print("\n=== PROBANDO CON USUARIO INVÁLIDO ===")
    resultado = sistema.prestar_libro(usuario_id=0, libro_id=2)  # ID=0 no autorizado
    
    print(f"📋 Respuesta del sistema: {resultado}")
    
    # 🎯 ASSERT: Verificar que se rechazó correctamente
    print("\n=== VERIFICANDO RECHAZO ===")
    assert resultado == "Usuario no autorizado", f"Esperado rechazo, pero obtuve '{resultado}'"
    print("✅ ¡Excelente! El sistema rechaza usuarios no autorizados")

# ================== STUBS ESPECIALIZADOS PARA TESTING AVANZADO ==================

class SpyDatabaseStub:
    """Stub 'espía' que registra todas las llamadas para verificar comportamiento"""
    
    def __init__(self):
        # Contadores para verificar llamadas
        self.libro_disponible_llamado = 0
        self.registrar_prestamo_llamado = 0
        self.llamadas_orden = []  # Para verificar orden de operaciones
        
        # Argumentos recibidos (para verificaciones)
        self.ultimo_libro_id = None
        self.ultimo_usuario_id = None
        self.ultimo_libro_id_registro = None
    
    def libro_disponible(self, libro_id):
        """Spy que registra llamadas y usa lógica par/impar"""
        self.libro_disponible_llamado += 1
        self.ultimo_libro_id = libro_id
        self.llamadas_orden.append(f"libro_disponible({libro_id})")
        
        # Misma lógica que DatabaseStub original
        return libro_id % 2 == 0
    
    def registrar_prestamo(self, usuario_id, libro_id):
        """Spy que registra llamadas de registro"""
        self.registrar_prestamo_llamado += 1
        self.ultimo_usuario_id = usuario_id
        self.ultimo_libro_id_registro = libro_id
        self.llamadas_orden.append(f"registrar_prestamo({usuario_id}, {libro_id})")
        return True

class SpyAuthStub:
    """Stub 'espía' que registra verificaciones de autorización"""
    
    def __init__(self):
        self.verificar_usuario_llamado = 0
        self.ultimo_usuario_verificado = None
        self.llamadas_orden = []
    
    def verificar_usuario(self, usuario_id):
        """Spy que registra llamadas de verificación"""
        self.verificar_usuario_llamado += 1
        self.ultimo_usuario_verificado = usuario_id
        self.llamadas_orden.append(f"verificar_usuario({usuario_id})")
        
        # Misma lógica que AuthStub original
        return usuario_id > 0

class FailingDatabaseStub:
    """Stub que simula errores de base de datos"""
    
    def __init__(self, fail_on_disponible=False, fail_on_registro=False):
        self.fail_on_disponible = fail_on_disponible
        self.fail_on_registro = fail_on_registro
    
    def libro_disponible(self, libro_id):
        if self.fail_on_disponible:
            raise Exception("Error simulado de base de datos en consulta")
        return libro_id % 2 == 0
    
    def registrar_prestamo(self, usuario_id, libro_id):
        if self.fail_on_registro:
            raise Exception("Error simulado de base de datos en registro")
        return True

class FailingAuthStub:
    """Stub que simula errores de autenticación"""
    
    def __init__(self, fail_on_verificar=False):
        self.fail_on_verificar = fail_on_verificar
    
    def verificar_usuario(self, usuario_id):
        if self.fail_on_verificar:
            raise Exception("Error simulado del sistema de autenticación")
        return usuario_id > 0

# ================== PRUEBAS PARAMETRIZADAS ==================

@pytest.mark.parametrize("usuario_id,libro_id,resultado_esperado", [
    # Casos exitosos (usuario autorizado + libro disponible)
    (1, 2, "Préstamo exitoso"),      # Caso básico positivo
    (5, 4, "Préstamo exitoso"),      # IDs más grandes
    (100, 1000, "Préstamo exitoso"), # IDs muy grandes
    (1, 0, "Préstamo exitoso"),      # Libro ID 0 (par = disponible)
    
    # Casos de usuario no autorizado
    (0, 2, "Usuario no autorizado"),   # Usuario ID 0
    (-1, 2, "Usuario no autorizado"),  # Usuario ID negativo
    (-100, 2, "Usuario no autorizado"), # Usuario ID muy negativo
    
    # Casos de libro no disponible (pero usuario autorizado)
    (1, 1, "Libro no disponible"),     # Libro ID impar
    (5, 3, "Libro no disponible"),     # Otro libro impar
    (10, 99, "Libro no disponible"),   # Libro ID impar grande
    (1, -1, "Libro no disponible"),    # Libro ID negativo impar
])
def test_prestamo_casos_parametrizados(usuario_id, libro_id, resultado_esperado):

    print(f"\n=== PROBANDO: Usuario={usuario_id}, Libro={libro_id} ===")
    
    # Arrange: Usar stubs normales para estos casos
    db_stub = DatabaseStub()
    auth_stub = AuthStub()
    sistema = BibliotecaSistema(db_stub, auth_stub)
    
    # Act: Ejecutar operación
    resultado = sistema.prestar_libro(usuario_id, libro_id)
    
    # Assert: Verificar resultado esperado
    assert resultado == resultado_esperado, f"Usuario={usuario_id}, Libro={libro_id}: esperado '{resultado_esperado}', obtuvo '{resultado}'"
    print(f"✅ Resultado correcto: {resultado}")

# ================== PRUEBAS DE ORDEN Y SHORT-CIRCUITING ==================

def test_orden_llamadas_caso_exitoso():
   
    print("\n=== VERIFICANDO ORDEN DE LLAMADAS (CASO EXITOSO) ===")
    
    # Arrange: Usar stubs espía
    spy_db = SpyDatabaseStub()
    spy_auth = SpyAuthStub()
    sistema = BibliotecaSistema(spy_db, spy_auth)
    
    # Act: Operación exitosa
    resultado = sistema.prestar_libro(usuario_id=1, libro_id=2)
    
    # Assert: Verificar resultado y orden
    assert resultado == "Préstamo exitoso"
    
    # Verificar que se llamaron todos los métodos exactamente una vez
    assert spy_auth.verificar_usuario_llamado == 1, "verificar_usuario debe llamarse exactamente 1 vez"
    assert spy_db.libro_disponible_llamado == 1, "libro_disponible debe llamarse exactamente 1 vez"
    assert spy_db.registrar_prestamo_llamado == 1, "registrar_prestamo debe llamarse exactamente 1 vez"
    
    # Verificar argumentos correctos
    assert spy_auth.ultimo_usuario_verificado == 1
    assert spy_db.ultimo_libro_id == 2
    assert spy_db.ultimo_usuario_id == 1
    assert spy_db.ultimo_libro_id_registro == 2
    
    print("✅ Orden de llamadas correcto en caso exitoso")

def test_short_circuit_usuario_no_autorizado():
  
    print("\n=== VERIFICANDO SHORT-CIRCUIT (USUARIO NO AUTORIZADO) ===")
    
    # Arrange: Stubs espía
    spy_db = SpyDatabaseStub()
    spy_auth = SpyAuthStub()
    sistema = BibliotecaSistema(spy_db, spy_auth)
    
    # Act: Usuario no autorizado
    resultado = sistema.prestar_libro(usuario_id=0, libro_id=2)
    
    # Assert: Verificar rechazo y optimización
    assert resultado == "Usuario no autorizado"
    
    # Verificar llamadas
    assert spy_auth.verificar_usuario_llamado == 1, "verificar_usuario SÍ debe llamarse"
    assert spy_db.libro_disponible_llamado == 0, "libro_disponible NO debe llamarse (short-circuit)"
    assert spy_db.registrar_prestamo_llamado == 0, "registrar_prestamo NO debe llamarse"
    
    print("✅ Short-circuit funcionando correctamente")

def test_short_circuit_libro_no_disponible():
   
    print("\n=== VERIFICANDO SHORT-CIRCUIT (LIBRO NO DISPONIBLE) ===")
    
    # Arrange: Stubs espía
    spy_db = SpyDatabaseStub()
    spy_auth = SpyAuthStub()
    sistema = BibliotecaSistema(spy_db, spy_auth)
    
    # Act: Libro no disponible (ID impar)
    resultado = sistema.prestar_libro(usuario_id=1, libro_id=3)
    
    # Assert: Verificar rechazo y que no se registra
    assert resultado == "Libro no disponible"
    
    # Verificar llamadas
    assert spy_auth.verificar_usuario_llamado == 1, "verificar_usuario SÍ debe llamarse"
    assert spy_db.libro_disponible_llamado == 1, "libro_disponible SÍ debe llamarse"
    assert spy_db.registrar_prestamo_llamado == 0, "registrar_prestamo NO debe llamarse"
    
    print("✅ Short-circuit en libro no disponible funcionando")

# ================== PRUEBAS DE MANEJO DE ERRORES ==================

def test_error_en_verificacion_usuario():
    """Prueba propagación de errores del sistema de autenticación"""
    print("\n=== PROBANDO MANEJO DE ERROR EN AUTENTICACIÓN ===")
    
    # Arrange: Auth que falla
    failing_auth = FailingAuthStub(fail_on_verificar=True)
    db_stub = DatabaseStub()
    sistema = BibliotecaSistema(db_stub, failing_auth)
    
    # Act & Assert: Debe propagar la excepción
    with pytest.raises(Exception, match="Error simulado del sistema de autenticación"):
        sistema.prestar_libro(usuario_id=1, libro_id=2)
    
    print("✅ Error de autenticación propagado correctamente")

def test_error_en_consulta_libro():
    """Prueba propagación de errores de base de datos en consulta"""
    print("\n=== PROBANDO MANEJO DE ERROR EN CONSULTA BD ===")
    
    # Arrange: BD que falla en consulta
    auth_stub = AuthStub()
    failing_db = FailingDatabaseStub(fail_on_disponible=True)
    sistema = BibliotecaSistema(failing_db, auth_stub)
    
    # Act & Assert: Debe propagar la excepción
    with pytest.raises(Exception, match="Error simulado de base de datos en consulta"):
        sistema.prestar_libro(usuario_id=1, libro_id=2)
    
    print("✅ Error de consulta BD propagado correctamente")

def test_error_en_registro_prestamo():
    """Prueba propagación de errores de base de datos en registro"""
    print("\n=== PROBANDO MANEJO DE ERROR EN REGISTRO ===")
    
    # Arrange: BD que falla en registro
    auth_stub = AuthStub()
    failing_db = FailingDatabaseStub(fail_on_registro=True)
    sistema = BibliotecaSistema(failing_db, auth_stub)
    
    # Act & Assert: Debe propagar la excepción
    with pytest.raises(Exception, match="Error simulado de base de datos en registro"):
        sistema.prestar_libro(usuario_id=1, libro_id=2)  # Pasa validaciones pero falla registro
    
    print("✅ Error de registro propagado correctamente")

# ================== PRUEBAS DE CASOS EXTREMOS ==================

@pytest.mark.parametrize("usuario_id,libro_id", [
    (None, 2),      # Usuario None
    (1, None),      # Libro None
    ("texto", 2),   # Usuario string
    (1, "texto"),   # Libro string
])
def test_tipos_invalidos(usuario_id, libro_id):
    """
    Prueba comportamiento con tipos de datos inválidos
    
    El sistema actual no valida tipos, por lo que pueden ocurrir errores.
    Estas pruebas documentan el comportamiento actual y detectarán
    cambios si se agrega validación de tipos en el futuro.
    """
    print(f"\n=== PROBANDO TIPOS INVÁLIDOS: Usuario={usuario_id}, Libro={libro_id} ===")
    
    # Arrange
    db_stub = DatabaseStub()
    auth_stub = AuthStub()
    sistema = BibliotecaSistema(db_stub, auth_stub)
    
    # Act & Assert: Debe fallar con TypeError o similar
    with pytest.raises((TypeError, AttributeError)):
        sistema.prestar_libro(usuario_id, libro_id)
    
    print("✅ Error de tipo detectado correctamente")

def test_tipos_float_comportamiento():
    """
    Prueba específica para tipos float - documenta comportamiento actual
    
    Descubrimiento: Los floats NO causan error en Python porque:
    - 1.5 > 0 es True (usuario autorizado)
    - 2.5 % 2 = 0.5 que es truthy, pero NO == 0 (libro no disponible)
    
    Este test documenta este comportamiento interesante.
    """
    print("\n=== PROBANDO COMPORTAMIENTO CON FLOATS ===")
    
    # Arrange
    db_stub = DatabaseStub()
    auth_stub = AuthStub()
    sistema = BibliotecaSistema(db_stub, auth_stub)
    
    # Case 1: Usuario float autorizado, libro entero disponible
    resultado1 = sistema.prestar_libro(usuario_id=1.5, libro_id=2)
    assert resultado1 == "Préstamo exitoso", "Float 1.5 > 0, debería estar autorizado"
    
    # Case 2: Usuario entero, libro float (impar por módulo)
    resultado2 = sistema.prestar_libro(usuario_id=1, libro_id=2.5)
    # 2.5 % 2 = 0.5 (no es exactamente 0), por lo que es "no disponible"
    assert resultado2 == "Libro no disponible", "Float 2.5 % 2 != 0, debería ser no disponible"
    
    # Case 3: Usuario float autorizado (¡Descubrimiento interesante!)
    resultado3 = sistema.prestar_libro(usuario_id=0.5, libro_id=2)
    assert resultado3 == "Préstamo exitoso", "Float 0.5 > 0 es True, por lo que SÍ está autorizado"
    
    # Case 4: Usuario float NO autorizado (debe ser <= 0)
    resultado4 = sistema.prestar_libro(usuario_id=0.0, libro_id=2)
    assert resultado4 == "Usuario no autorizado", "Float 0.0 == 0, no autorizado"
    
    resultado5 = sistema.prestar_libro(usuario_id=-0.5, libro_id=2)
    assert resultado5 == "Usuario no autorizado", "Float -0.5 < 0, no autorizado"
    
    print("✅ Comportamiento con floats documentado correctamente")

# ================== PRUEBAS DE RE-ENTRANCIA ==================

def test_multiples_prestamos_consecutivos():
    """
    Prueba múltiples préstamos consecutivos del mismo libro
    
    En el sistema actual con stubs, esto debería funcionar porque
    los stubs no mantienen estado. En un sistema real, el segundo
    préstamo debería fallar porque el libro ya estaría prestado.
    """
    print("\n=== PROBANDO MÚLTIPLES PRÉSTAMOS CONSECUTIVOS ===")
    
    # Arrange: Usar spy para contar llamadas
    spy_db = SpyDatabaseStub()
    spy_auth = SpyAuthStub()
    sistema = BibliotecaSistema(spy_db, spy_auth)
    
    # Act: Dos préstamos del mismo libro
    resultado1 = sistema.prestar_libro(usuario_id=1, libro_id=2)
    resultado2 = sistema.prestar_libro(usuario_id=2, libro_id=2)
    
    # Assert: Ambos deberían ser exitosos con stubs
    assert resultado1 == "Préstamo exitoso"
    assert resultado2 == "Préstamo exitoso"
    
    # Verificar que se registraron ambos préstamos
    assert spy_db.registrar_prestamo_llamado == 2, "Deben registrarse 2 préstamos"
    assert spy_auth.verificar_usuario_llamado == 2, "Deben verificarse 2 usuarios"
    
    print("✅ Múltiples préstamos procesados (nota: en sistema real, el segundo fallaría)")

# ================== EJEMPLO DE PRUEBA BASADA EN PROPIEDADES ==================

def test_propiedad_usuario_libro_validos():
    """
    PRUEBA BASADA EN PROPIEDADES: Todos los casos donde usuario > 0 Y libro es par
    deben resultar en préstamo exitoso
    
    Esta es una prueba de "invariante" que verifica una regla general
    del sistema sin importar los valores específicos.
    """
    print("\n=== VERIFICANDO PROPIEDAD: USUARIO_VÁLIDO ∧ LIBRO_DISPONIBLE ⇒ ÉXITO ===")
    
    # Casos que cumplen la propiedad: usuario > 0 AND libro % 2 == 0
    casos_validos = [
        (1, 2), (5, 4), (10, 6), (100, 1000),
        (7, 0), (3, 8), (25, 50)
    ]
    
    for usuario_id, libro_id in casos_validos:
        # Arrange
        db_stub = DatabaseStub()
        auth_stub = AuthStub()
        sistema = BibliotecaSistema(db_stub, auth_stub)
        
        # Act
        resultado = sistema.prestar_libro(usuario_id, libro_id)
        
        # Assert: PROPIEDAD debe cumplirse
        assert resultado == "Préstamo exitoso", f"Propiedad violada para usuario={usuario_id}, libro={libro_id}"
    
    print("✅ Propiedad verificada: Usuario válido + Libro disponible = Éxito")

