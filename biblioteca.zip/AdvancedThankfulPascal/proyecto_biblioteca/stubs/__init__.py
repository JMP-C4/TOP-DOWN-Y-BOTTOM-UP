# Paquete de stubs para pruebas Top Down
# Este archivo hace que stubs sea un paquete de Python

__version__ = "1.0.0"
__author__ = "Sistema Biblioteca"

# Importaciones disponibles del paquete stubs
from .database_stub import DatabaseStub
from .auth_stub import AuthStub

__all__ = ["DatabaseStub", "AuthStub"]